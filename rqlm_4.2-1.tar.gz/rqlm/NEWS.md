# rqlm 4.2-1 (2024-01-09)

- Some minor corrections are added.

# rqlm 4.1-1 (2024-01-08)

- New bootstrap-based inference methods are added, and many of existing functions were updated.

# rqlm 3.1-1 (2023-12-31)

- Quantile approximation tool is added.

# rqlm 2.1-1 (2023-12-31)

- Bias correction tool is added.

# rqlm 1.1-1 (2023-12-13)

- first version released on GitHub
