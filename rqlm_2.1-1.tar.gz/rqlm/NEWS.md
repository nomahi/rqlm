# rqlm 2.1-1 (2023-12-31)

- Bias correction tool is added.

# rqlm 1.1-1 (2023-12-13)

- first version released on GitHub
