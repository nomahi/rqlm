rqlm <- function(formula, data, family=gaussian, bias.correct=FALSE, method="Wang-Long", eform=FALSE, digits=4){

	gm1 <- glm(formula, data=data, family = family, x=TRUE)
	
	if(bias.correct==TRUE){ library(brglm2); gm3 <- glm(formula, data=data, family = family, method="brglmFit", type="correction") }
	
	y <- gm1$y		# 結果変数ベクトル
	X <- gm1$x		# 説明変数行列

	n <- dim(X)[1]
	p <- dim(X)[2]

	###
	
	data$id <- 1:n

	if(method=="Standard") gm2 <- gee.lz(formula, data=data, id=id, family=family)
	if(method=="Fay-Graubard") gm2 <- gee.fg(formula, data=data, id=id, family=family)
	if(method=="Gosho") gm2 <- gee.gst(formula, data=data, id=id, family=family)
	if(method=="Kauermann-Carroll") gm2 <- gee.kc(formula, data=data, id=id, family=family)
	if(method=="Morel") gm2 <- gee.mbn(formula, data=data, id=id, family=family)
	if(method=="Mancl-DeRouen") gm2 <- gee.md(formula, data=data, id=id, family=family)
	if(method=="Mackinnon") gm2 <- gee.mk(formula, data=data, id=id, family=family)
	if(method=="Pan") gm2 <- gee.pan(formula, data=data, id=id, family=family)
	if(method=="Wang-Long") gm2 <- gee.wl(formula, data=data, id=id, family=family)

	wp <- p*(0:(p-1)) + 1:p
	
	VR <- gm2$RV
	
	##
	
	coef <- gm1$coefficients	# 回帰係数
	
	if(bias.correct==TRUE) coef <- gm3$coefficients		# バイアス補正後の回帰係数の推定値

	SE <- sqrt(diag(VR))

	ci1 <- coef - qnorm(.975)*SE
	ci2 <- coef + qnorm(.975)*SE

	Z <- coef/SE
	P <- 2*pnorm(-abs(Z))
	
	out <- data.frame(coef,SE,ci1,ci2,P)
	colnames(out) <- c("coef","SE","CL","CU","P-value")

	if(eform==TRUE){
		
		coef <- exp(coef)
		ci1 <- exp(ci1)
		ci2 <- exp(ci2)
		out <- data.frame(coef,SE,ci1,ci2,P)
		colnames(out) <- c("exp(coef)","SE","CL","CU","P-value")
		
	}
	
	out <- round(out, digits)
	
	return(out)

}

mat.sqrt.inv <- function(A)
{
    ei <- eigen(A)
    d <- ei$values
    d <- (d + abs(d))/2
    d2 <- 1/sqrt(d)
    d2[d == 0] <- 0
	if(length(d2)>=2) D2 <- diag(d2)
	if(length(d2)==1) D2 <- d2
    ans <- ei$vectors %*% D2 %*% t(ei$vectors)
    return(ans)
}


gee.lz <- function (formula, id, family = gaussian, data, corstr = "independence") 
{
    if (is.null(data$id)) {
        index <- which(names(data) == id)
        data$id <- data[, index]
    }
    init <- model.frame(formula, data)
    init$num <- 1:length(init[, 1])
    if (any(is.na(init))) {
        index <- na.omit(init)$num
        data <- data[index, ]
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
    else {
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
	capture.output(						# geeのメッセージを出さない仕様に
	suppressMessages(
	suppressWarnings(
    gee.fit <- gee(formula, data = data, id = id, family = family, 
        corstr = corstr, scale.fix=TRUE, scale.value=1)
	)
	)
	)
    beta_est <- gee.fit$coefficient
    alpha <- 0
    len <- length(beta_est)
    len_vec <- len^2
    data$id <- gee.fit$id
    cluster <- cluster.size(data$id)
    ncluster <- max(cluster$n)
    size <- cluster$m
    mat$subj <- rep(unique(data$id), cluster$n)
    if (is.character(corstr)) {
        var <- switch(corstr, independence = cormax.ind(ncluster), 
            exchangeable = cormax.exch(ncluster, alpha), `AR-M` = cormax.ar1(ncluster, 
                alpha), unstructured = summary(gee.fit)$working.correlation, 
            )
    }
    else {
        print(corstr)
        stop("'working correlation structure' not recognized")
    }
    if (is.character(family)) {
        family <- switch(family, gaussian = "gaussian", binomial = "binomial", 
            poisson = "poisson")
    }
    else {
        if (is.function(family)) {
            family <- family()[[1]]
        }
        else {
            print(family)
            stop("'family' not recognized")
        }
    }
    cov.beta <- unstr <- matrix(0, nrow = len, ncol = len)
    step11 <- matrix(0, nrow = len, ncol = len)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var_i = var[1:cluster$n[i], 1:cluster$n[i]]
        if (family == "gaussian") {
            xx <- t(covariate) %*% solve(var_i) %*% covariate
            step11 <- step11 + xx
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                cluster$n[i]) %*% var_i %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), cluster$n[i])
            xx <- t(D) %*% solve(Vi) %*% D
            step11 <- step11 + xx
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i]) %*% 
                var_i %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i])
            xx <- t(D) %*% solve(Vi) %*% D
            step11 <- step11 + xx
        }
    }
    step12 <- matrix(0, nrow = len, ncol = len)
    step13 <- matrix(0, nrow = len_vec, ncol = 1)
    step14 <- matrix(0, nrow = len_vec, ncol = len_vec)
    p <- matrix(0, nrow = len_vec, ncol = size)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var_i = var[1:cluster$n[i], 1:cluster$n[i]]
        if (family == "gaussian") {
            xy <- t(covariate) %*% solve(var_i) %*% (y - covariate %*% 
                beta_est)
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                cluster$n[i]) %*% var_i %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% (y - exp(covariate %*% 
                beta_est))
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i]) %*% 
                var_i %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% (y - exp(covariate %*% 
                beta_est)/(1 + exp(covariate %*% beta_est)))
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
    }
    for (i in 1:size) {
        dif <- (p[, i] - step13/size) %*% t(p[, i] - step13/size)
        step14 <- step14 + dif
    }
    cov.beta <- solve(step11) %*% (step12) %*% solve(step11)
    cov.var <- size/(size - 1) * kronecker(solve(step11), solve(step11)) %*% 
        step14 %*% kronecker(solve(step11), solve(step11))
    return(list(GEE=gee.fit, RV = cov.beta, VRV = cov.var))
}


gee.mk <- function (formula, id, family = gaussian, data, corstr = "independence") 
{
    if (is.null(data$id)) {
        index <- which(names(data) == id)
        data$id <- data[, index]
    }
    init <- model.frame(formula, data)
    init$num <- 1:length(init[, 1])
    if (any(is.na(init))) {
        index <- na.omit(init)$num
        data <- data[index, ]
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
    else {
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
	capture.output(						# geeのメッセージを出さない仕様に
	suppressMessages(
	suppressWarnings(
    gee.fit <- gee(formula, data = data, id = id, family = family, 
        corstr = corstr, scale.fix=TRUE, scale.value=1)
	)
	)
	)
    beta_est <- gee.fit$coefficient
    alpha <- 0
    len <- length(beta_est)
    len_vec <- len^2
    data$id <- gee.fit$id
    cluster <- cluster.size(data$id)
    ncluster <- max(cluster$n)
    size <- cluster$m
    mat$subj <- rep(unique(data$id), cluster$n)
    if (is.character(corstr)) {
        var <- switch(corstr, independence = cormax.ind(ncluster), 
            exchangeable = cormax.exch(ncluster, alpha), `AR-M` = cormax.ar1(ncluster, 
                alpha), unstructured = summary(gee.fit)$working.correlation, 
            )
    }
    else {
        print(corstr)
        stop("'working correlation structure' not recognized")
    }
    if (is.character(family)) {
        family <- switch(family, gaussian = "gaussian", binomial = "binomial", 
            poisson = "poisson")
    }
    else {
        if (is.function(family)) {
            family <- family()[[1]]
        }
        else {
            print(family)
            stop("'family' not recognized")
        }
    }
    cov.beta <- unstr <- matrix(0, nrow = len, ncol = len)
    step11 <- matrix(0, nrow = len, ncol = len)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var_i = var[1:cluster$n[i], 1:cluster$n[i]]
        if (family == "gaussian") {
            xx <- t(covariate) %*% solve(var_i) %*% covariate
            step11 <- step11 + xx
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                cluster$n[i]) %*% var_i %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), cluster$n[i])
            xx <- t(D) %*% solve(Vi) %*% D
            step11 <- step11 + xx
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i]) %*% 
                var_i %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i])
            xx <- t(D) %*% solve(Vi) %*% D
            step11 <- step11 + xx
        }
    }
    step12 <- matrix(0, nrow = len, ncol = len)
    step13 <- matrix(0, nrow = len_vec, ncol = 1)
    step14 <- matrix(0, nrow = len_vec, ncol = len_vec)
    p <- matrix(0, nrow = len_vec, ncol = size)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var_i = var[1:cluster$n[i], 1:cluster$n[i]]
        if (family == "gaussian") {
            xy <- t(covariate) %*% solve(var_i) %*% (y - covariate %*% 
                beta_est)
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                cluster$n[i]) %*% var_i %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% (y - exp(covariate %*% 
                beta_est))
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i]) %*% 
                var_i %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% (y - exp(covariate %*% 
                beta_est)/(1 + exp(covariate %*% beta_est)))
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
    }
    for (i in 1:size) {
        dif <- (p[, i] - step13/size) %*% t(p[, i] - step13/size)
        step14 <- step14 + dif
    }
    scale <- size/(size - len)
    cov.beta <- scale * solve(step11) %*% (step12) %*% solve(step11)
    cov.var <- scale^2 * size/(size - 1) * kronecker(solve(step11), 
        solve(step11)) %*% step14 %*% kronecker(solve(step11), 
        solve(step11))
    return(list(GEE=gee.fit, RV = cov.beta, VRV = cov.var))
}


gee.kc <- function (formula, id, family = gaussian, data, corstr = "independence") 
{
    if (is.null(data$id)) {
        index <- which(names(data) == id)
        data$id <- data[, index]
    }
    init <- model.frame(formula, data)
    init$num <- 1:length(init[, 1])
    if (any(is.na(init))) {
        index <- na.omit(init)$num
        data <- data[index, ]
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
    else {
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
	capture.output(						# geeのメッセージを出さない仕様に
	suppressMessages(
	suppressWarnings(
    gee.fit <- gee(formula, data = data, id = id, family = family, 
        corstr = corstr, scale.fix=TRUE, scale.value=1)
	)
	)
	)
    beta_est <- gee.fit$coefficient
    alpha <- 0
    len <- length(beta_est)
    len_vec <- len^2
    data$id <- gee.fit$id
    cluster <- cluster.size(data$id)
    ncluster <- max(cluster$n)
    size <- cluster$m
    mat$subj <- rep(unique(data$id), cluster$n)
    if (is.character(corstr)) {
        var <- switch(corstr, independence = cormax.ind(ncluster), 
            exchangeable = cormax.exch(ncluster, alpha), `AR-M` = cormax.ar1(ncluster, 
                alpha), unstructured = summary(gee.fit)$working.correlation, 
            )
    }
    else {
        print(corstr)
        stop("'working correlation structure' not recognized")
    }
    if (is.character(family)) {
        family <- switch(family, gaussian = "gaussian", binomial = "binomial", 
            poisson = "poisson")
    }
    else {
        if (is.function(family)) {
            family <- family()[[1]]
        }
        else {
            print(family)
            stop("'family' not recognized")
        }
    }
    cov.beta <- unstr <- matrix(0, nrow = len, ncol = len)
    step11 <- matrix(0, nrow = len, ncol = len)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var_i = var[1:cluster$n[i], 1:cluster$n[i]]
        if (family == "gaussian") {
            xx <- t(covariate) %*% solve(var_i) %*% covariate
            step11 <- step11 + xx
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                cluster$n[i]) %*% var_i %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), cluster$n[i])
            xx <- t(D) %*% solve(Vi) %*% D
            step11 <- step11 + xx
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i]) %*% 
                var_i %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i])
            xx <- t(D) %*% solve(Vi) %*% D
            step11 <- step11 + xx
        }
    }
    step12 <- matrix(0, nrow = len, ncol = len)
    step13 <- matrix(0, nrow = len_vec, ncol = 1)
    step14 <- matrix(0, nrow = len_vec, ncol = len_vec)
    p <- matrix(0, nrow = len_vec, ncol = size)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var_i = var[1:cluster$n[i], 1:cluster$n[i]]
        if (family == "gaussian") {
            xy <- t(covariate) %*% solve(var_i) %*% mat.sqrt.inv(cormax.ind(cluster$n[i]) - 
                covariate %*% solve(step11) %*% t(covariate) %*% 
                  solve(var_i)) %*% (y - covariate %*% beta_est)
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                cluster$n[i]) %*% var_i %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% mat.sqrt.inv(cormax.ind(cluster$n[i]) - 
                D %*% solve(step11) %*% t(D) %*% solve(Vi)) %*% 
                (y - exp(covariate %*% beta_est))
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i]) %*% 
                var_i %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% mat.sqrt.inv(cormax.ind(cluster$n[i]) - 
                D %*% solve(step11) %*% t(D) %*% solve(Vi)) %*% 
                (y - exp(covariate %*% beta_est)/(1 + exp(covariate %*% 
                  beta_est)))
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
    }
    for (i in 1:size) {
        dif <- (p[, i] - step13/size) %*% t(p[, i] - step13/size)
        step14 <- step14 + dif
    }
    cov.beta <- solve(step11) %*% (step12) %*% solve(step11)
    cov.var <- size/(size - 1) * kronecker(solve(step11), solve(step11)) %*% 
        step14 %*% kronecker(solve(step11), solve(step11))
    return(list(GEE=gee.fit, RV = cov.beta, VRV = cov.var))
}


gee.fg <- function (formula, id, family = gaussian, data, corstr = "independence", b = 0.75) 
{
    if (is.null(data$id)) {
        index <- which(names(data) == id)
        data$id <- data[, index]
    }
    init <- model.frame(formula, data)
    init$num <- 1:length(init[, 1])
    if (any(is.na(init))) {
        index <- na.omit(init)$num
        data <- data[index, ]
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
    else {
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
	capture.output(						# geeのメッセージを出さない仕様に
	suppressMessages(
	suppressWarnings(
    gee.fit <- gee(formula, data = data, id = id, family = family, 
        corstr = corstr, scale.fix=TRUE, scale.value=1)
	)
	)
	)
    beta_est <- gee.fit$coefficient
    alpha <- 0
    len <- length(beta_est)
    len_vec <- len^2
    data$id <- gee.fit$id
    cluster <- cluster.size(data$id)
    ncluster <- max(cluster$n)
    size <- cluster$m
    mat$subj <- rep(unique(data$id), cluster$n)
    if (is.character(corstr)) {
        var <- switch(corstr, independence = cormax.ind(ncluster), 
            exchangeable = cormax.exch(ncluster, alpha), `AR-M` = cormax.ar1(ncluster, 
                alpha), unstructured = summary(gee.fit)$working.correlation, 
            )
    }
    else {
        print(corstr)
        stop("'working correlation structure' not recognized")
    }
    if (is.character(family)) {
        family <- switch(family, gaussian = "gaussian", binomial = "binomial", 
            poisson = "poisson")
    }
    else {
        if (is.function(family)) {
            family <- family()[[1]]
        }
        else {
            print(family)
            stop("'family' not recognized")
        }
    }
    cov.beta <- unstr <- matrix(0, nrow = len, ncol = len)
    step11 <- matrix(0, nrow = len, ncol = len)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        ncluster = cluster$n[i]
        var1 = var[1:ncluster, 1:ncluster]
        if (family == "gaussian") {
            Vi = gee.fit$scale * var
            xx <- t(covariate) %*% solve(Vi) %*% covariate
            step11 <- step11 + xx
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                ncluster) %*% var1 %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), ncluster)
            xx <- t(D) %*% solve(Vi) %*% D
            step11 <- step11 + xx
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), ncluster) %*% 
                var1 %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), ncluster)
            xx <- t(D) %*% solve(Vi) %*% D
            step11 <- step11 + xx
        }
    }
    step12 <- matrix(0, nrow = len, ncol = len)
    step13 <- matrix(0, nrow = len_vec, ncol = 1)
    step14 <- matrix(0, nrow = len_vec, ncol = len_vec)
    p <- matrix(0, nrow = len_vec, ncol = size)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        ncluster = cluster$n[i]
        var1 = var[1:ncluster, 1:ncluster]
        if (family == "gaussian") {
            Vi = gee.fit$scale * var
            xx <- t(covariate) %*% solve(Vi) %*% covariate
            Qi <- xx %*% solve(step11)
            Ai <- diag((1 - pmin(b, diag(Qi)))^(-0.5))
            xy <- Ai %*% t(covariate) %*% solve(Vi) %*% (y - 
                covariate %*% beta_est)
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                ncluster) %*% var1 %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), ncluster)
            xx <- t(D) %*% solve(Vi) %*% D
            Qi <- xx %*% solve(step11)
            Ai <- diag((1 - pmin(b, diag(Qi)))^(-0.5))
            xy <- Ai %*% t(D) %*% solve(Vi) %*% (y - exp(covariate %*% 
                beta_est))
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), ncluster) %*% 
                var1 %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), ncluster)
            xx <- t(D) %*% solve(Vi) %*% D
            Qi <- xx %*% solve(step11)
            Ai <- diag((1 - pmin(b, diag(Qi)))^(-0.5))
            xy <- Ai %*% t(D) %*% solve(Vi) %*% (y - exp(covariate %*% 
                beta_est)/(1 + exp(covariate %*% beta_est)))
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
    }
    for (i in 1:size) {
        dif <- (p[, i] - step13/size) %*% t(p[, i] - step13/size)
        step14 <- step14 + dif
    }
    cov.beta <- solve(step11) %*% (step12) %*% solve(step11)
    cov.var <- size/(size - 1) * kronecker(solve(step11), solve(step11)) %*% 
        step14 %*% kronecker(solve(step11), solve(step11))
    return(list(GEE=gee.fit, RV = cov.beta, VRV = cov.var))
}


gee.md <- function (formula, id, family = gaussian, data, corstr = "independence") 
{
    if (is.null(data$id)) {
        index <- which(names(data) == id)
        data$id <- data[, index]
    }
    init <- model.frame(formula, data)
    init$num <- 1:length(init[, 1])
    if (any(is.na(init))) {
        index <- na.omit(init)$num
        data <- data[index, ]
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
    else {
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
	capture.output(						# geeのメッセージを出さない仕様に
	suppressMessages(
	suppressWarnings(
    gee.fit <- gee(formula, data = data, id = id, family = family, 
        corstr = corstr, scale.fix=TRUE, scale.value=1)
	)
	)
	)
    beta_est <- gee.fit$coefficient
    alpha <- 0
    len <- length(beta_est)
    len_vec <- len^2
    data$id <- gee.fit$id
    cluster <- cluster.size(data$id)
    ncluster <- max(cluster$n)
    size <- cluster$m
    mat$subj <- rep(unique(data$id), cluster$n)
    if (is.character(corstr)) {
        var <- switch(corstr, independence = cormax.ind(ncluster), 
            exchangeable = cormax.exch(ncluster, alpha), `AR-M` = cormax.ar1(ncluster, 
                alpha), unstructured = summary(gee.fit)$working.correlation, 
            )
    }
    else {
        print(corstr)
        stop("'working correlation structure' not recognized")
    }
    if (is.character(family)) {
        family <- switch(family, gaussian = "gaussian", binomial = "binomial", 
            poisson = "poisson")
    }
    else {
        if (is.function(family)) {
            family <- family()[[1]]
        }
        else {
            print(family)
            stop("'family' not recognized")
        }
    }
    cov.beta <- unstr <- matrix(0, nrow = len, ncol = len)
    step11 <- matrix(0, nrow = len, ncol = len)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var_i = var[1:cluster$n[i], 1:cluster$n[i]]
        if (family == "gaussian") {
            xx <- t(covariate) %*% solve(var_i) %*% covariate
            step11 <- step11 + xx
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                cluster$n[i]) %*% var_i %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), cluster$n[i])
            xx <- t(D) %*% solve(Vi) %*% D
            step11 <- step11 + xx
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i]) %*% 
                var_i %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i])
            xx <- t(D) %*% solve(Vi) %*% D
            step11 <- step11 + xx
        }
    }
    step12 <- matrix(0, nrow = len, ncol = len)
    step13 <- matrix(0, nrow = len_vec, ncol = 1)
    step14 <- matrix(0, nrow = len_vec, ncol = len_vec)
    p <- matrix(0, nrow = len_vec, ncol = size)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var_i = var[1:cluster$n[i], 1:cluster$n[i]]
        if (family == "gaussian") {
            xy <- t(covariate) %*% solve(var_i) %*% solve(cormax.ind(cluster$n[i]) - 
                covariate %*% solve(step11) %*% t(covariate) %*% 
                  solve(var_i)) %*% (y - covariate %*% beta_est)
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                cluster$n[i]) %*% var_i %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% solve(cormax.ind(cluster$n[i]) - 
                D %*% solve(step11) %*% t(D) %*% solve(Vi)) %*% 
                (y - exp(covariate %*% beta_est))
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i]) %*% 
                var_i %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% solve(cormax.ind(cluster$n[i]) - 
                D %*% solve(step11) %*% t(D) %*% solve(Vi)) %*% 
                (y - exp(covariate %*% beta_est)/(1 + exp(covariate %*% 
                  beta_est)))
            step12 <- step12 + xy %*% t(xy)
            step13 <- step13 + vec(xy %*% t(xy))
            p[, i] <- vec(xy %*% t(xy))
        }
    }
    for (i in 1:size) {
        dif <- (p[, i] - step13/size) %*% t(p[, i] - step13/size)
        step14 <- step14 + dif
    }
    cov.beta <- solve(step11) %*% (step12) %*% solve(step11)
    cov.var <- size/(size - 1) * kronecker(solve(step11), solve(step11)) %*% 
        step14 %*% kronecker(solve(step11), solve(step11))
    return(list(GEE=gee.fit, RV = cov.beta, VRV = cov.var))
}



gee.mbn <- function (formula, id, family = gaussian, data, corstr = "independence", d = 2, r = 1) 
{
    if (is.null(data$id)) {
        index <- which(names(data) == id)
        data$id <- data[, index]
    }
    init <- model.frame(formula, data)
    init$num <- 1:length(init[, 1])
    if (any(is.na(init))) {
        index <- na.omit(init)$num
        data <- data[index, ]
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
    else {
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
	capture.output(						# geeのメッセージを出さない仕様に
	suppressMessages(
	suppressWarnings(
    gee.fit <- gee(formula, data = data, id = id, family = family, 
        corstr = corstr, scale.fix=TRUE, scale.value=1)
	)
	)
	)

    beta_est <- gee.fit$coefficient
    alpha <- 0
    scale <- summary(gee.fit)$scale
    len <- length(beta_est)
    len_vec <- len^2
    data$id <- gee.fit$id
    cluster <- cluster.size(data$id)
    ncluster <- max(cluster$n)
    size <- cluster$m
    mat$subj <- rep(unique(data$id), cluster$n)
    if (is.character(corstr)) {
        var <- switch(corstr, independence = cormax.ind(ncluster), 
            exchangeable = cormax.exch(ncluster, alpha), `AR-M` = cormax.ar1(ncluster, 
                alpha), unstructured = summary(gee.fit)$working.correlation, 
            )
    }
    else {
        print(corstr)
        stop("'working correlation structure' not recognized")
    }
    if (is.character(family)) {
        family <- switch(family, gaussian = "gaussian", binomial = "binomial", 
            poisson = "poisson")
    }
    else {
        if (is.function(family)) {
            family <- family()[[1]]
        }
        else {
            print(family)
            stop("'family' not recognized")
        }
    }
    cov.beta <- unstr <- matrix(0, nrow = len, ncol = len)
    step11 <- matrix(0, nrow = len, ncol = len)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        ncluster = cluster$n[i]
        var1 = var[1:ncluster, 1:ncluster]
        if (family == "gaussian") {
            Vi <- gee.fit$scale * var
            xx <- t(covariate) %*% solve(Vi) %*% covariate
            step11 <- step11 + xx
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                ncluster) %*% var1 %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), ncluster)
            xx <- t(D) %*% solve(Vi) %*% D
            step11 <- step11 + xx
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), ncluster) %*% 
                var1 %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), ncluster)
            xx <- t(D) %*% solve(Vi) %*% D
            step11 <- step11 + xx
        }
    }
    k <- (sum(cluster$n) - 1)/(sum(cluster$n) - len) * size/(size - 
        1)
    delta <- ifelse(size > ((d + 1) * len), len/(size - len), 
        1/d)
    step00 <- matrix(0, nrow = len, ncol = len)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        ncluster = cluster$n[i]
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var1 = var[1:ncluster, 1:ncluster]
        if (family == "gaussian") {
            Vi <- gee.fit$scale * var
            xy <- t(covariate) %*% solve(Vi) %*% (y - covariate %*% 
                beta_est)
            step00 <- step00 + xy %*% t(xy)
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                ncluster) %*% var1 %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), ncluster)
            xy <- t(D) %*% solve(Vi) %*% (y - exp(covariate %*% 
                beta_est))
            step00 <- step00 + xy %*% t(xy)
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), ncluster) %*% 
                var1 %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), ncluster)
            xy <- t(D) %*% solve(Vi) %*% (y - exp(covariate %*% 
                beta_est)/(1 + exp(covariate %*% beta_est)))
            step00 <- step00 + xy %*% t(xy)
        }
    }
    xi <- pmax(r, sum(diag(solve(step11) %*% step00))/len)
    step12 <- matrix(0, nrow = len, ncol = len)
    step13 <- matrix(0, nrow = len_vec, ncol = 1)
    step14 <- matrix(0, nrow = len_vec, ncol = len_vec)
    p <- matrix(0, nrow = len_vec, ncol = size)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        ncluster = cluster$n[i]
        var1 = var[1:ncluster, 1:ncluster]
        if (family == "gaussian") {
            Vi <- gee.fit$scale * var
            xy <- t(covariate) %*% solve(Vi) %*% (k * (y - covariate %*% 
                beta_est) %*% t(y - covariate %*% beta_est) + 
                delta * xi * Vi) %*% solve(Vi) %*% covariate
            step12 <- step12 + xy
            step13 <- step13 + vec(xy)
            p[, i] <- vec(xy)
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                ncluster) %*% var %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), ncluster)
            xy <- t(D) %*% solve(Vi) %*% (k * (y - exp(covariate %*% 
                beta_est)) %*% t(y - exp(covariate %*% beta_est)) + 
                delta * xi * Vi) %*% solve(Vi) %*% D
            step12 <- step12 + xy
            step13 <- step13 + vec(xy)
            p[, i] <- vec(xy)
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), ncluster) %*% 
                var1 %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), ncluster)
            xy <- t(D) %*% solve(Vi) %*% (k * (y - exp(covariate %*% 
                beta_est)/(1 + exp(covariate %*% beta_est))) %*% 
                t(y - exp(covariate %*% beta_est)/(1 + exp(covariate %*% 
                  beta_est))) + delta * xi * Vi) %*% solve(Vi) %*% 
                D
            step12 <- step12 + xy
            step13 <- step13 + vec(xy)
            p[, i] <- vec(xy)
        }
    }
    for (i in 1:size) {
        dif <- (p[, i] - step13/size) %*% t(p[, i] - step13/size)
        step14 <- step14 + dif
    }
    cov.beta <- solve(step11) %*% (step12) %*% solve(step11)
    cov.var <- size/(size - 1) * kronecker(solve(step11), solve(step11)) %*% 
        step14 %*% kronecker(solve(step11), solve(step11))
    return(list(GEE=gee.fit, RV = cov.beta, VRV = cov.var))
}

gee.pan <- function (formula, id, family = gaussian, data, corstr = "independence") 
{
    if (is.null(data$id)) {
        index <- which(names(data) == id)
        data$id <- data[, index]
    }
    init <- model.frame(formula, data)
    init$num <- 1:length(init[, 1])
    if (any(is.na(init))) {
        index <- na.omit(init)$num
        data <- data[index, ]
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
    else {
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
	
	capture.output(						# geeのメッセージを出さない仕様に
	suppressMessages(
	suppressWarnings(
    gee.fit <- gee(formula, data = data, id = id, family = family, 
        corstr = corstr, scale.fix=TRUE, scale.value=1)
	)
	)
	)
    beta_est <- gee.fit$coefficient
    alpha <- 0
	
    len <- length(beta_est)
    len_vec <- len^2
    data$id <- gee.fit$id
    cluster <- cluster.size(data$id)
    ncluster <- max(cluster$n)
    size <- cluster$m
    mat$subj <- rep(unique(data$id), cluster$n)
    if (is.character(corstr)) {
        var <- switch(corstr, independence = cormax.ind(ncluster), 
            exchangeable = cormax.exch(ncluster, alpha), `AR-M` = cormax.ar1(ncluster, 
                alpha), unstructured = summary(gee.fit)$working.correlation, 
            )
    }
    else {
        print(corstr)
        stop("'working correlation structure' not recognized")
    }
    if (is.character(family)) {
        family <- switch(family, gaussian = "gaussian", binomial = "binomial", 
            poisson = "poisson")
    }
    else {
        if (is.function(family)) {
            family <- family()[[1]]
        }
        else {
            print(family)
            stop("'family' not recognized")
        }
    }
    cov.beta <- unstr <- matrix(0, nrow = len, ncol = len)
    step <- matrix(0, nrow = cluster$n[1], ncol = cluster$n[1])
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        if (family == "gaussian") {
            resid <- (y - covariate %*% beta_est) %*% t(y - covariate %*% 
                beta_est)
            step <- step + resid
        }
        else if (family == "poisson") {
            resid <- (y - exp(covariate %*% beta_est)) %*% t(y - 
                exp(covariate %*% beta_est))
            B <- matrix(0, nrow = cluster$n[i], ncol = cluster$n[i])
            diag(B) <- 1/sqrt(exp(covariate %*% beta_est))
            step <- step + B %*% resid %*% B
        }
        else if (family == "binomial") {
            resid <- (y - exp(covariate %*% beta_est)/(1 + exp(covariate %*% 
                beta_est))) %*% t(y - exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est)))
            B <- matrix(0, nrow = cluster$n[i], ncol = cluster$n[i])
            diag(B) <- 1/sqrt(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)
            step <- step + B %*% resid %*% B
        }
    }
    unstr <- step/size
    step11 <- matrix(0, nrow = len, ncol = len)
    step12 <- matrix(0, nrow = len, ncol = len)
    step13 <- matrix(0, nrow = len_vec, ncol = 1)
    step14 <- matrix(0, nrow = len_vec, ncol = len_vec)
    p <- matrix(0, nrow = len_vec, ncol = size)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var_i = var[1:cluster$n[i], 1:cluster$n[i]]
        if (family == "gaussian") {
            xy <- t(covariate) %*% solve(var_i) %*% unstr %*% 
                solve(var) %*% covariate
            xx <- t(covariate) %*% solve(var_i) %*% covariate
            step11 <- step11 + xx
            step12 <- step12 + xy
            step13 <- step13 + vec(xy)
            p[, i] <- vec(xy)
        }
        else if (family == "poisson") {
            A <- matrix(0, nrow = cluster$n[i], ncol = cluster$n[i])
            diag(A) <- exp(covariate %*% beta_est)
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                cluster$n[i]) %*% var_i %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% sqrt(A) %*% unstr %*% 
                sqrt(A) %*% solve(Vi) %*% D
            xx <- t(D) %*% solve(Vi) %*% D
            step12 <- step12 + xy
            step11 <- step11 + xx
            step13 <- step13 + vec(xy)
            p[, i] <- vec(xy)
        }
        else if (family == "binomial") {
            A <- matrix(0, nrow = cluster$n[i], ncol = cluster$n[i])
            diag(A) <- exp(covariate %*% beta_est)/(1 + exp(covariate %*% 
                beta_est))^2
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i]) %*% 
                var_i %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% sqrt(A) %*% unstr %*% 
                sqrt(A) %*% solve(Vi) %*% D
            xx <- t(D) %*% solve(Vi) %*% D
            step12 <- step12 + xy
            step11 <- step11 + xx
            step13 <- step13 + vec(xy)
            p[, i] <- vec(xy)
        }
    }
    for (i in 1:size) {
        dif <- (p[, i] - step13/size) %*% t(p[, i] - step13/size)
        step14 <- step14 + dif
    }
    cov.beta <- solve(step11) %*% (step12) %*% solve(step11)
    cov.var <- size/(size - 1) * kronecker(solve(step11), solve(step11)) %*% 
        step14 %*% kronecker(solve(step11), solve(step11))
    return(list(GEE=gee.fit, RV = cov.beta, VRV = cov.var))
}


gee.gst <- function(formula, id, family = gaussian, data, corstr = "independence") 
{
    if (is.null(data$id)) {
        index <- which(names(data) == id)
        data$id <- data[, index]
    }
    init <- model.frame(formula, data)
    init$num <- 1:length(init[, 1])
    if (any(is.na(init))) {
        index <- na.omit(init)$num
        data <- data[index, ]
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
    else {
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
	capture.output(						# geeのメッセージを出さない仕様に
	suppressMessages(
	suppressWarnings(
    gee.fit <- gee(formula, data = data, id = id, family = family, 
        corstr = corstr, scale.fix=TRUE, scale.value=1)
	)
	)
	)
    beta_est <- gee.fit$coefficient
    alpha <- 0							# geesmvの関数から、ここだけ変更すれば、そのまま使える

    len <- length(beta_est)
    len_vec <- len^2
    data$id <- gee.fit$id
    cluster <- cluster.size(data$id)
    ncluster <- max(cluster$n)
    size <- cluster$m
    mat$subj <- rep(unique(data$id), cluster$n)
    if (is.character(corstr)) {
        var <- switch(corstr, independence = cormax.ind(ncluster), 
            exchangeable = cormax.exch(ncluster, alpha), `AR-M` = cormax.ar1(ncluster, 
                alpha), unstructured = summary(gee.fit)$working.correlation, 
            )
    }
    else {
        print(corstr)
        stop("'working correlation structure' not recognized")
    }
    if (is.character(family)) {
        family <- switch(family, gaussian = "gaussian", binomial = "binomial", 
            poisson = "poisson")
    }
    else {
        if (is.function(family)) {
            family <- family()[[1]]
        }
        else {
            print(family)
            stop("'family' not recognized")
        }
    }
    cov.beta <- unstr <- matrix(0, nrow = len, ncol = len)
    step <- matrix(0, nrow = cluster$n[1], ncol = cluster$n[1])
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        if (family == "gaussian") {
            resid <- (y - covariate %*% beta_est) %*% t(y - covariate %*% 
                beta_est)
            step <- step + resid
        }
        else if (family == "poisson") {
            resid <- (y - exp(covariate %*% beta_est)) %*% t(y - 
                exp(covariate %*% beta_est))
            B <- matrix(0, nrow = cluster$n[i], ncol = cluster$n[i])
            diag(B) <- 1/sqrt(exp(covariate %*% beta_est))
            step <- step + B %*% resid %*% B
        }
        else if (family == "binomial") {
            resid <- (y - exp(covariate %*% beta_est)/(1 + exp(covariate %*% 
                beta_est))) %*% t(y - exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est)))
            B <- matrix(0, nrow = cluster$n[i], ncol = cluster$n[i])
            diag(B) <- 1/sqrt(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)
            step <- step + B %*% resid %*% B
        }
    }
    unstr <- step/(size - len)
    step11 <- matrix(0, nrow = len, ncol = len)
    step12 <- matrix(0, nrow = len, ncol = len)
    step13 <- matrix(0, nrow = len_vec, ncol = 1)
    step14 <- matrix(0, nrow = len_vec, ncol = len_vec)
    p <- matrix(0, nrow = len_vec, ncol = size)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var_i = var[1:cluster$n[i], 1:cluster$n[i]]
        if (family == "gaussian") {
            xy <- t(covariate) %*% solve(var_i) %*% unstr %*% 
                solve(var) %*% covariate
            xx <- t(covariate) %*% solve(var_i) %*% covariate
            step11 <- step11 + xx
            step12 <- step12 + xy
            step13 <- step13 + vec(xy)
            p[, i] <- vec(xy)
        }
        else if (family == "poisson") {
            A <- matrix(0, nrow = cluster$n[i], ncol = cluster$n[i])
            diag(A) <- exp(covariate %*% beta_est)
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                cluster$n[i]) %*% var_i %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% sqrt(A) %*% unstr %*% 
                sqrt(A) %*% solve(Vi) %*% D
            xx <- t(D) %*% solve(Vi) %*% D
            step12 <- step12 + xy
            step11 <- step11 + xx
            step13 <- step13 + vec(xy)
            p[, i] <- vec(xy)
        }
        else if (family == "binomial") {
            A <- matrix(0, nrow = cluster$n[i], ncol = cluster$n[i])
            diag(A) <- exp(covariate %*% beta_est)/(1 + exp(covariate %*% 
                beta_est))^2
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i]) %*% 
                var_i %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% sqrt(A) %*% unstr %*% 
                sqrt(A) %*% solve(Vi) %*% D
            xx <- t(D) %*% solve(Vi) %*% D
            step12 <- step12 + xy
            step11 <- step11 + xx
            step13 <- step13 + vec(xy)
            p[, i] <- vec(xy)
        }
    }
    for (i in 1:size) {
        dif <- (p[, i] - step13/size) %*% t(p[, i] - step13/size)
        step14 <- step14 + dif
    }
    cov.beta <- solve(step11) %*% (step12) %*% solve(step11)
    cov.var <- size/(size - 1) * kronecker(solve(step11), solve(step11)) %*% 
        step14 %*% kronecker(solve(step11), solve(step11))
    return(list(GEE=gee.fit, RV = cov.beta, VRV = cov.var))									# ここも変更（元の関数では、SEだけが出る。共分散行列を出す）
}


gee.wl <- function(formula, id, family = gaussian, data, corstr = "independence") 
{
    if (is.null(data$id)) {
        index <- which(names(data) == id)
        data$id <- data[, index]
    }
    init <- model.frame(formula, data)
    init$num <- 1:length(init[, 1])
    if (any(is.na(init))) {
        index <- na.omit(init)$num
        data <- data[index, ]
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
	else {
        m <- model.frame(formula, data)
        mt <- attr(m, "terms")
        data$response <- model.response(m, "numeric")
        mat <- as.data.frame(model.matrix(formula, m))
    }
	capture.output(						# geeのメッセージを出さない仕様に
	suppressMessages(
	suppressWarnings(
    gee.fit <- gee(formula, data = data, id = id, family = family, 
        corstr = corstr, scale.fix=TRUE, scale.value=1)
	)
	)
	)
    beta_est <- gee.fit$coefficient
    alpha <- 0
    len <- length(beta_est)
    len_vec <- len^2
    data$id <- gee.fit$id
    cluster <- cluster.size(data$id)
    ncluster <- max(cluster$n)
    size <- cluster$m
    mat$subj <- rep(unique(data$id), cluster$n)
    if (is.character(corstr)) {
        var <- switch(corstr, independence = cormax.ind(ncluster), 
            exchangeable = cormax.exch(ncluster, alpha), `AR-M` = cormax.ar1(ncluster, 
                alpha), unstructured = summary(gee.fit)$working.correlation, 
            )
    }
    else {
        print(corstr)
        stop("'working correlation structure' not recognized")
    }
    if (is.character(family)) {
        family <- switch(family, gaussian = "gaussian", binomial = "binomial", 
            poisson = "poisson")
    }
    else {
        if (is.function(family)) {
            family <- family()[[1]]
        }
        else {
            print(family)
            stop("'family' not recognized")
        }
    }
    m <- model.frame(formula, data)
    mat <- as.data.frame(model.matrix(formula, m))
    mat$subj <- rep(unique(data$id), cluster$n)
    cov.beta <- unstr <- matrix(0, nrow = len, ncol = len)
    step01 <- matrix(0, nrow = len, ncol = len)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var_i = var[1:cluster$n[i], 1:cluster$n[i]]
        if (family == "gaussian") {
            xx <- t(covariate) %*% solve(var_i) %*% covariate
            step01 <- step01 + xx
        }
        else if (family == "poisson") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                cluster$n[i]) %*% var_i %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), cluster$n[i])
            xx <- t(D) %*% solve(Vi) %*% D
            step01 <- step01 + xx
        }
        else if (family == "binomial") {
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i]) %*% 
                var_i %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i])
            xx <- t(D) %*% solve(Vi) %*% D
            step01 <- step01 + xx
        }
    }
    step <- matrix(0, nrow = cluster$n[i], ncol = cluster$n[i])
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var_i = var[1:cluster$n[i], 1:cluster$n[i]]
        if (family == "gaussian") {
            resid <- solve(cormax.ind(cluster$n[i]) - covariate %*% 
                solve(step01) %*% t(covariate) %*% solve(var_i)) %*% 
                (y - covariate %*% beta_est)
            step <- step + resid %*% t(resid)
        }
        else if (family == "poisson") {
            B <- matrix(0, nrow = cluster$n[i], ncol = cluster$n[i])
            diag(B) <- 1/sqrt(exp(covariate %*% beta_est))
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                cluster$n[i]) %*% var_i %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), cluster$n[i])
            resid <- B %*% solve(cormax.ind(cluster$n[i]) - D %*% 
                solve(step01) %*% t(D) %*% solve(Vi)) %*% (y - 
                exp(covariate %*% beta_est))
            step <- step + resid %*% t(resid)
        }
        else if (family == "binomial") {
            B <- matrix(0, nrow = cluster$n[i], ncol = cluster$n[i])
            diag(B) <- 1/sqrt(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i]) %*% 
                var_i %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i])
            resid <- B %*% solve(cormax.ind(cluster$n[i]) - D %*% 
                solve(step01) %*% t(D) %*% solve(Vi)) %*% (y - 
                exp(covariate %*% beta_est)/(1 + exp(covariate %*% 
                  beta_est)))
            step <- step + resid %*% t(resid)
        }
    }
    unstr <- step/size
    step11 <- matrix(0, nrow = len, ncol = len)
    step12 <- matrix(0, nrow = len, ncol = len)
    step13 <- matrix(0, nrow = len_vec, ncol = 1)
    step14 <- matrix(0, nrow = len_vec, ncol = len_vec)
    p <- matrix(0, nrow = len_vec, ncol = size)
    for (i in 1:size) {
        y <- as.matrix(data$response[data$id == unique(data$id)[i]])
        covariate <- as.matrix(subset(mat[, -length(mat[1, ])], 
            mat$subj == unique(data$id)[i]))
        var_i = var[1:cluster$n[i], 1:cluster$n[i]]
        if (family == "gaussian") {
            xy <- t(covariate) %*% solve(var_i) %*% unstr %*% 
                solve(var) %*% covariate
            xx <- t(covariate) %*% solve(var_i) %*% covariate
            step11 <- step11 + xx
            step12 <- step12 + xy
            step13 <- step13 + vec(xy)
            p[, i] <- vec(xy)
        }
        else if (family == "poisson") {
            B <- matrix(0, nrow = cluster$n[i], ncol = cluster$n[i])
            diag(B) <- exp(covariate %*% beta_est)
            D <- mat.prod(covariate, exp(covariate %*% beta_est))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est))), 
                cluster$n[i]) %*% var_i %*% diag(sqrt(c(exp(covariate %*% 
                beta_est))), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% sqrt(B) %*% unstr %*% 
                sqrt(B) %*% solve(Vi) %*% D
            xx <- t(D) %*% solve(Vi) %*% D
            step11 <- step11 + xx
            step12 <- step12 + xy
            step13 <- step13 + vec(xy)
            p[, i] <- vec(xy)
        }
        else if (family == "binomial") {
            B <- matrix(0, nrow = cluster$n[i], ncol = cluster$n[i])
            diag(B) <- exp(covariate %*% beta_est)/(1 + exp(covariate %*% 
                beta_est))^2
            D <- mat.prod(covariate, exp(covariate %*% beta_est)/((1 + 
                exp(covariate %*% beta_est))^2))
            Vi <- diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i]) %*% 
                var_i %*% diag(sqrt(c(exp(covariate %*% beta_est)/(1 + 
                exp(covariate %*% beta_est))^2)), cluster$n[i])
            xy <- t(D) %*% solve(Vi) %*% sqrt(B) %*% unstr %*% 
                sqrt(B) %*% solve(Vi) %*% D
            xx <- t(D) %*% solve(Vi) %*% D
            step12 <- step12 + xy
            step11 <- step11 + xx
            step13 <- step13 + vec(xy)
            p[, i] <- vec(xy)
        }
    }
    for (i in 1:size) {
        dif <- (p[, i] - step13/size) %*% t(p[, i] - step13/size)
        step14 <- step14 + dif
    }
    cov.beta <- solve(step11) %*% (step12) %*% solve(step11)
    cov.var <- size/(size - 1) * kronecker(solve(step11), solve(step11)) %*% 
        step14 %*% kronecker(solve(step11), solve(step11))
    return(list(GEE=gee.fit, RV = cov.beta, VRV = cov.var))
}

